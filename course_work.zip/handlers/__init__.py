import handlers.other_handlers
import handlers.user_handlers
import handlers.client_handlers
import handlers.teacher_handlers
